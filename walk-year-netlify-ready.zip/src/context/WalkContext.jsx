import React, { createContext, useState, useEffect } from "react";

export const WalkContext = createContext();

export const WalkProvider = ({ children }) => {
  const [steps, setSteps] = useState(0);
  const [goal, setGoal] = useState(1000000);

  useEffect(() => {
    const savedSteps = localStorage.getItem("walkSteps");
    if (savedSteps) setSteps(parseInt(savedSteps, 10));
  }, []);

  useEffect(() => {
    localStorage.setItem("walkSteps", steps);
  }, [steps]);

  const addSteps = (newSteps) => setSteps((prev) => prev + newSteps);

  return (
    <WalkContext.Provider value={{ steps, goal, addSteps, setGoal }}>
      {children}
    </WalkContext.Provider>
  );
};
