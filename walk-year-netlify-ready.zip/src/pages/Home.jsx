import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <section className="home">
      <h1>Welcome to Walk Year</h1>
      <p>Track your steps, set your goals, and make every step count!</p>
      <Link className="btn" to="/dashboard">Go to Dashboard</Link>
    </section>
  );
}
