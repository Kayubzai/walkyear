import React, { useContext, useState } from "react";
import { WalkContext } from "../context/WalkContext";
import ProgressRing from "../components/ProgressRing";

export default function Dashboard() {
  const { steps, goal, addSteps } = useContext(WalkContext);
  const [input, setInput] = useState("");

  const handleAdd = () => {
    if (input) {
      addSteps(parseInt(input, 10));
      setInput("");
    }
  };

  return (
    <div className="dashboard">
      <h2>My Progress</h2>
      <ProgressRing progress={(steps / goal) * 100} />
      <p>{steps.toLocaleString()} / {goal.toLocaleString()} steps</p>

      <div className="input-area">
        <input
          type="number"
          placeholder="Enter steps"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button onClick={handleAdd}>Add Steps</button>
      </div>
    </div>
  );
}
