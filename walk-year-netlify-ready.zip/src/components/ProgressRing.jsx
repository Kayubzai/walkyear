import React from "react";

export default function ProgressRing({ progress }) {
  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <svg className="progress-ring" width="150" height="150">
      <circle
        className="progress-ring-bg"
        stroke="#ddd"
        strokeWidth="10"
        fill="transparent"
        r={radius}
        cx="75"
        cy="75"
      />
      <circle
        className="progress-ring-value"
        stroke="#4caf50"
        strokeWidth="10"
        fill="transparent"
        r={radius}
        cx="75"
        cy="75"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
      />
      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dy=".3em"
        fontSize="20"
        fill="#333"
      >
        {Math.round(progress)}%
      </text>
    </svg>
  );
}
