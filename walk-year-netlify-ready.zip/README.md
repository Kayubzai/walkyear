# Walk Year
A year-long fitness tracker web app built with React + Vite.

### Features
- Track daily and yearly walking progress
- Set personal step goals
- Visual progress rings
- Local storage saving

### Development
```bash
npm install
npm run dev
```

### Build for Netlify
```bash
npm run build
```
Publish the `dist` folder on Netlify.
